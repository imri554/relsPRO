# Speaker Notes: NFRI Investment Signals Presentation (EXPANDED)
## For Non-Technical Economics Research Team

---

## OVERVIEW

This expanded presentation now has 25 slides (up from 10) with much more detail on:
1. What earnings calls are and why they matter
2. How LLMs work and why they're better than keyword search
3. Step-by-step walkthrough of the entire pipeline
4. Detailed explanation of each component of the hesitation index
5. How we aggregate individual firm data into economy-wide metrics

**Total Time: Plan for 20-25 minutes + Q&A**

---

## SLIDE 1: Title Slide (30 seconds)
**Script:**
"Good morning everyone. Today I'll be presenting our work on extracting NFRI investment signals from earnings call transcripts using large language models. I've expanded this presentation to give you a thorough walkthrough of our methodology—how we go from raw text to quantifiable economic indicators. Let's dive in."

**Timing:** 0:00-0:30

---

## SLIDE 2: Research Question (1 minute)
**Script:**
"Let me start with our core research question: What percentage of the economy is currently expanding its capital base?

This is critical for understanding investment trends but difficult to answer in real-time. The key insight is that earnings calls are forward-looking. Unlike financial statements—which tell us what happened last quarter and are heavily regulated—earnings calls let executives discuss their plans, concerns, and intentions in free-flowing conversation.

These calls reveal capital allocation plans weeks or even months before they show up in official statistics from BEA. We're essentially trying to capture investment sentiment before it materializes."

**Key points:**
- Emphasize "forward-looking" vs "backward-looking"
- Real-time vs lagged official data

**Timing:** 0:30-1:30

---

## SLIDE 3: Understanding Earnings Calls (1 minute 30 seconds)
**Script:**
"For those less familiar with earnings calls, let me explain the structure. Every quarter, publicly-traded companies hold a conference call to discuss their financial results.

Part 1 is prepared remarks—the CEO or CFO presents revenue, earnings, market conditions, strategic initiatives, and their outlook. This is scripted and carefully worded.

Part 2 is the Q&A session—and this is where it gets interesting. Analysts ask unscripted questions, and executives respond in real-time. This is where we learn about investment plans, project delays, supply chain issues, and concerns they're facing.

For example, an executive might say—[read the quote on screen]. Notice this tells us: dollar amount, timeline, category, constraints, and confidence level. That's exactly what we want to capture."

**Key points:**
- Q&A is more valuable than prepared remarks
- Real information comes out in responses
- Show the quote as an example of rich information

**Timing:** 1:30-3:00

---

## SLIDE 4: The Data Challenge (1 minute 30 seconds)
**Script:**
"Here's the challenge we face. A typical earnings call transcript is 10,000 to 30,000 words—that's like a small book. The information we want is scattered throughout the document. Investment discussion might be in the prepared remarks, or buried in question 7, or mentioned across multiple answers.

The language is also vague and conditional. Executives say things like 'we're looking to expand,' or 'if conditions permit,' or 'we're considering several projects.' And often there are competing signals—a firm might say they're expanding in one area while delaying projects in another.

What we need to extract is very specific: directional signal, dollar amounts, investment category, whether there are constraints, confidence level, and time horizon. 

This is a classic unstructured-to-structured data transformation problem."

**Key points:**
- Emphasize the scale (10K-30K words per call, 200K calls total)
- Language is complex and conditional
- Need very specific structured output

**Timing:** 3:00-4:30

---

## SLIDE 5: Enter LLMs (2 minutes)
**Script:**
"This is where Large Language Models come in. So what is an LLM?

Think of it as an AI system that has been trained on massive amounts of text—books, articles, documents—and has learned to understand language context and meaning, not just keywords.

The key capabilities for our purpose are: it can understand context and meaning—including negation, conditional statements, and nuance. It can extract specific information from complex documents. It follows detailed instructions consistently. And crucially, it can output structured data—basically filling out a form based on what it reads.

Let me contrast this with traditional methods. If you use keyword search for 'expand,' and a CEO says 'We plan to NOT expand,' the keyword method finds 'expand' and gives you a false positive. It missed the negation.

An LLM, by contrast, understands that 'NOT expand' means the opposite. It can handle 'if-then' logic naturally. And it can synthesize information across the entire document rather than just matching words.

This is why LLMs are a game-changer for this type of work."

**Key points:**
- Explain LLMs in accessible terms (avoid technical jargon)
- The contrast with keyword search is very important
- Understanding context vs matching words

**Timing:** 4:30-6:30

---

## SLIDE 6: Step 1 - Data Sourcing (1 minute 30 seconds)
**Script:**
"Now let me walk you through our process step by step.

Step 1 is sourcing the earnings call data. We use FactSet as our data provider, and we've written a SQL query—which is attached in the appendix—to pull all final-version earnings transcripts.

Our selection criteria are: Geography—we focus on US-based companies using SIC code filtering. Time period—2016 to present, so about 8-9 years of data. Firm size—we filter to firms with market cap over $250 million and that discuss meaningful investments. And topic—we make sure they're discussing investments in US operations.

After applying all these filters, our final dataset contains approximately 200,000 earnings call transcripts. That's our raw material."

**Key points:**
- FactSet is the industry-standard provider
- Filters are reasonable and justifiable
- 200K transcripts is a large dataset

**Timing:** 6:30-8:00

---

## SLIDE 7: Step 2 - The Prompt (2 minutes)
**Script:**
"Step 2 is designing what we call the 'prompt'—which is our instruction to the LLM. Think of this like designing a survey questionnaire, but for a machine.

A good prompt has three components.

First, context: We tell the LLM what type of document this is—an earnings call transcript—and what we're trying to analyze—investment signals. We provide key definitions. For instance, what counts as 'expansion' versus 'contraction.'

Second, instructions: These are specific questions we want answered. Is the firm expanding or contracting? What dollar amount is mentioned? What category—equipment, structures, or intellectual property? Are there any barriers to execution? What's the confidence level?

Third, output format: We request JSON—which is a structured data format. This ensures consistent, machine-readable output. And we include validation rules—if something is unclear, return 'null' rather than guessing. We want conservative coding.

The prompt design is absolutely critical. A vague prompt gives noisy results. A well-designed prompt gives high-quality, consistent extractions."

**Key points:**
- Prompt = survey questionnaire for a machine
- Three parts: context, instructions, format
- Emphasize the importance of specificity

**Timing:** 8:00-10:00

---

## SLIDE 8: Prompt Example (1 minute)
**Script:**
"Here's a simplified version of what our actual prompt looks like. [Walk through the text on screen]

You are analyzing an earnings call transcript. Task: Extract investment signals. For each transcript, identify these five specific things: directional signal, amount in dollars, BEA category, execution constraints, and confidence level.

Output this as JSON with these exact field names. If information is unclear, return null for that field.

This is simplified—our actual prompt is longer and more detailed—but this gives you the idea. Very specific instructions, structured output format, conservative when uncertain."

**Key points:**
- This is simplified but representative
- Point out the structure
- JSON = machine-readable structured data

**Timing:** 10:00-11:00

---

## SLIDE 9: Step 3 - LLM Processing (1 minute 30 seconds)
**Script:**
"Step 3 is the actual processing. Here's what happens when we 'run' the LLM on each transcript.

Step 1: We load an earnings call transcript from our database.
Step 2: We send it to the LLM along with our prompt.
Step 3: The LLM reads the entire document—all 10,000 to 30,000 words.
Step 4: It extracts the requested information, following our instructions.
Step 5: It returns structured JSON output with all the fields we asked for.

We repeat this process for all 200,000 transcripts. Now, you might wonder about computational cost—this does take meaningful compute time, but it's very manageable with modern infrastructure. The key is that once we've processed historical transcripts, we only need to process new transcripts as they come out—maybe 2,000-3,000 per quarter going forward."

**Key points:**
- Emphasize it's a systematic, repeatable process
- Processing 200K transcripts is computationally feasible
- Only process new transcripts going forward

**Timing:** 11:00-12:30

---

## SLIDE 10: JSON Output Example (1 minute)
**Script:**
"Here's what the output actually looks like for a single earnings call. This is real structured JSON data from one company.

You can see all the fields: the company name, directional signal shows 'expansion,' amount is $850 million, BEA category is equipment specifically information processing equipment, execution constraint is flagged as true with medium severity, financial condition is loosening—meaning easier access to capital—confidence is high, and there's an overall strategic context of highly expansionary sentiment.

This structured output is what we get for each of the 200,000 transcripts. Each transcript becomes a row of structured data that we can then aggregate and analyze."

**Key points:**
- This is real data, not hypothetical
- Point out each field
- This demonstrates the transformation from text to data

**Timing:** 12:30-13:30

---

## SLIDE 11: From JSON to Dataset (1 minute)
**Script:**
"Step 5 is converting all these JSON outputs into a dataset. Each transcript becomes one row in a table with all these columns: company, date, signal direction, amount, category, constraints, and confidence.

So we go from 200,000 individual JSON outputs to one large structured dataset with 200,000 rows and multiple columns. This is now traditional structured data that we can aggregate, analyze, and use to build time series.

The hard part—extracting information from unstructured text—is done. Now we move to building the indices."

**Key points:**
- Visualize the transformation: JSON → tabular data
- This is now just a regular dataset
- Ready for aggregation and analysis

**Timing:** 13:30-14:30

---

## SLIDE 12: Building the Index - Intro (1 minute 30 seconds)
**Script:**
"Now, Step 6: building the hesitation index. Our goal is to create a single metric that captures economy-wide investment hesitation.

We identified five distinct indicators of hesitation:

Number one: Momentum drops—these are firms that were expanding but are now decelerating. They're still growing but slowing down.

Number two: Execution barriers—supply chain disruptions, labor shortages, permitting delays—things that physically impede investment.

Number three: Delays and cancellations—projects explicitly marked as delayed or cancelled.

Number four: Financial tightening—firms citing financial constraints, higher borrowing costs, or credit challenges.

And number five: Financial loosening—which is the opposite. This captures easier financing conditions and enters our formula with a NEGATIVE weight since it reduces hesitation.

Let me walk through each of these in detail."

**Key points:**
- Goal: single metric for economy-wide hesitation
- Five components, each capturing different dimension
- Loosening gets negative weight (reduces hesitation)

**Timing:** 14:30-16:00

---

## SLIDE 13: Momentum Component (2 minutes)
**Script:**
"Let's start with the momentum drop component. We're tracking firms that are expanding yet decelerating.

Here's an example of strong momentum turning weak: In Q4 2023, a firm says 'We're expanding rapidly'—we code their overall signal as +1.0, very strong. Then in Q1 2024, they say 'Still expanding strong'—but now their signal is +0.8. Still positive, still expanding, but the momentum dropped from 1.0 to 0.8. That's a deceleration, and we flag it as a momentum drop.

Contrast that with weak momentum: A firm says 'We're contracting' with signal -0.5, then next quarter 'Still contracting' at -0.3. This is actually an improvement—getting less negative—so it's NOT a momentum drop.

The calculation at the quarterly level is: we count the number of firms whose previous signal was above 0.15—so they were expanding—AND whose current signal dropped by more than 30%. We divide by the total number of firms, and we weight by NAICS industry codes to match BEA investment composition. This gives us the momentum drop share."

**Key points:**
- Momentum drop = deceleration while still expanding
- Walk through both examples carefully
- NAICS weighting ensures proper industry representation

**Timing:** 16:00-18:00

---

## SLIDE 14: Execution Barriers (1 minute 30 seconds)
**Script:**
"Component two: execution barrier share. This identifies constraints that impede investment execution.

The LLM looks for specific phrases. High severity examples: 'Supply chain disruptions delaying equipment orders,' or 'Permitting issues holding up construction.' Medium severity: 'Labor shortages impacting project timelines.' Low severity: 'Minor delays but nothing material.'

We code the severity level, and we flag any firm that mentions execution constraints. The calculation is simple: number of firms flagging execution_constraint equals true, divided by total firms.

This captures real-world friction—even if a firm wants to invest, can they actually execute? Supply chains, labor markets, and regulatory processes all create barriers."

**Key points:**
- Focus on real constraints to execution
- Severity levels matter
- Different from financial constraints

**Timing:** 18:00-19:30

---

## SLIDE 15: Delays Component (1 minute 30 seconds)
**Script:**
"Component three: delays and cancellations share. This is firms explicitly postponing or cancelling investment projects.

The left side shows examples that get flagged: 'We've delayed the facility expansion to Q3,' 'The project has been postponed indefinitely,' 'We've cancelled the capex initiative,' or 'Holding off on that investment.'

The right side shows examples that DON'T get flagged: 'Timeline unchanged,' 'On track for completion,' 'Accelerating our investment,' 'Normal project timing.'

The LLM is quite good at distinguishing between explicit delays and normal project management discussion. The calculation is: firms with delayed OR cancelled projects divided by total firms."

**Key points:**
- Explicit delays and cancellations only
- LLM can distinguish from normal project updates
- This is a direct measure of hesitation

**Timing:** 19:30-21:00

---

## SLIDE 16: Financial Conditions (1 minute 30 seconds)
**Script:**
"Components four and five capture financial conditions—both tightening and loosening.

On the left, financial tightening. Indicators include: 'Credit conditions tightening,' 'Higher borrowing costs,' 'Limited access to capital,' or 'Cash flow pressures.' The interpretation is that firms are facing financial headwinds, which may cause them to hesitate before investing.

On the right, financial loosening—the opposite. Indicators include: 'Easier access to credit,' 'Lower interest rates,' 'Strong cash position,' or 'Ample liquidity.' When financial conditions are favorable, firms are less likely to hesitate. This is why loosening enters our formula with a NEGATIVE weight—it reduces hesitation.

Both are important dimensions of the investment environment, but they push in opposite directions."

**Key points:**
- Two sides of the same coin
- Tightening adds to hesitation
- Loosening subtracts from hesitation (negative weight)

**Timing:** 21:00-22:30

---

## SLIDE 17: The Formula (1 minute 30 seconds)
**Script:**
"Now we combine all five components into the hesitation index using this weighted formula.

[Read the formula on screen slowly]

Why these specific weights? 

Momentum gets 35%—the highest—because it's the most important. It captures change in investment trajectory, which is the most predictive signal.

Execution barriers and delays each get 25%. These are direct obstacles to investment realization.

Financial tightening gets 10%. It's constraining, but large firms can often work around financial constraints—they have multiple funding sources.

Financial loosening gets negative 5%. It offsets hesitation, but the effect is smaller.

These weights were determined through a combination of economic reasoning and empirical testing to maximize predictive power."

**Key points:**
- Walk through the formula slowly
- Justify each weight with economic intuition
- Tested empirically to validate

**Timing:** 22:30-24:00

---

## SLIDE 18: NAICS Weighting (1 minute 30 seconds)
**Script:**
"An important technical detail: industry weighting using NAICS codes.

The problem is that not all industries invest equally in capital. Manufacturing invests heavily in equipment. Tech invests heavily in intellectual property like software and R&D. Retail invests less overall.

If we just count firms equally, we'd overweight retail and underweight manufacturing, which would distort our index.

The solution: we weight each firm by its industry's share of total BEA investment. We map NAICS codes to BEA industry categories, then to annual investment shares.

For example, if manufacturing represents 30% of total NFRI in the economy, then manufacturing firms get 30% weight in our index. This ensures our index reflects the actual economy-wide investment composition, not just the composition of firms that hold earnings calls."

**Key points:**
- Different industries invest different amounts
- Weighting ensures proper representation
- Matches actual economy-wide investment patterns

**Timing:** 24:00-25:30

---

## SLIDE 19: Time Series Output (1 minute)
**Script:**
"The result of all this is a quarterly time series—one hesitation score per quarter from 2016 to present.

Higher values mean more hesitation. Lower values mean less hesitation. You can see the time series plotted here [point to chart]. Notice the spikes during periods we'd expect heightened uncertainty—early 2020 during COVID, for instance.

This single series aggregates information from hundreds of thousands of earnings calls, capturing economy-wide investment sentiment in real-time."

**Key points:**
- One number per quarter
- Higher = more hesitation
- Real-time economic indicator

**Timing:** 25:30-26:30

---

## SLIDE 20: PCA Introduction (1 minute 30 seconds)
**Script:**
"Step 7: Principal Component Analysis, or PCA. Now, this is a statistical technique, but let me explain it in non-technical terms.

Imagine you have three correlated measures: the hesitation score we just built, an urgency score that captures how quickly firms want to act, and average time horizon which captures near-term versus long-term thinking.

These three measures are correlated—they move together—because they're all driven by some underlying factors. PCA finds those underlying patterns that explain their co-movement.

Why use PCA? It reduces noise and extracts the 'signal' from our correlated measures. It creates orthogonal components—meaning each component captures an independent dimension of variation. And our hypothesis was that one of these components would capture behavioral 'patience with planning'—and that turned out to be true."

**Key points:**
- PCA in accessible terms (no math)
- Finding underlying patterns
- Orthogonal = independent dimensions

**Timing:** 26:30-28:00

---

## SLIDE 21: PC2 Interpretation (1 minute 30 seconds)
**Script:**
"Our key finding: the second principal component—PC2—is our behavioral investment signal.

When PC2 is negative, we see these characteristics: high hesitation, short time horizons, firms thinking quarter-to-quarter, a 'wait and see' mentality. The interpretation is low confidence, impatient, poor planning environment. This predicts LOWER investment.

When PC2 is positive, we see the opposite: low hesitation, long time horizons, firms planning years ahead, a 'full steam ahead' mentality. The interpretation is high confidence, patient, strong planning environment. This predicts HIGHER investment.

Notice this is capturing something behavioral and psychological—it's not just about current conditions, but about firms' willingness to commit to long-term plans. That's why it has predictive power."

**Key points:**
- PC2 = behavioral signal
- Two states clearly defined
- It's about confidence and planning, not just current conditions

**Timing:** 28:00-29:30

---

## SLIDE 22: Cross-Validation (1 minute 30 seconds)
**Script:**
"Now, validation. We tested 72 different model configurations.

We looked at four BEA targets: total NFRI investment plus three subcategories—equipment, structures, and intellectual property. For each target, we tested three transformations: year-over-year growth, quarter-over-quarter growth, and index levels. We tested different feature sets and two model types: elastic net and ridge regression.

Our cross-validation uses a rolling window. Training window is 20 quarters—five years of data. We test two quarters ahead. We step forward by two quarters each time, giving us seven folds total. This mimics real forecasting where you have limited historical BEA data available.

We evaluate on three metrics: RMSE for accuracy, correlation for linear relationship strength, and directional accuracy for getting the sign of changes correct.

In total, 504 individual models tested across all combinations."

**Key points:**
- Systematic testing, not just one model
- Rolling window mimics real forecasting
- Multiple evaluation metrics

**Timing:** 29:30-31:00

---

## SLIDE 23: Best Results (1 minute 30 seconds)
**Script:**
"Here are our top performing models. And I want to emphasize—these correlations are quite strong for macro forecasting.

For total investment, the hesitation index at six-quarter lag shows correlation of .771. That's very strong. It makes intuitive sense: aggregate hesitation today predicts reduced investment a year and a half later.

For equipment growth, we get even better performance—correlation of .798 using sentiment PC1 at only two-quarter lag. Equipment responds faster to sentiment shifts.

Intellectual property investment shows correlation of .796 at six quarters using capacity utilization as the predictor.

Structures is tougher—correlation of .316 with behavioral PC2 at two quarters. This is modest, but structures investment is notoriously volatile and hard to predict, so this is actually consistent with the literature.

The key insight: different investment categories have different optimal lead times and predictors."

**Key points:**
- Emphasize correlation magnitudes (.77-.80 is strong)
- Different categories, different lead times
- Structures being hard to predict is expected

**Timing:** 31:00-32:30

---

## SLIDE 24: Next Steps (1 minute)
**Script:**
"Let me quickly cover next steps.

Near-term: validate with truly out-of-sample 2024-2025 data, add sector-level granularity, and test alternative LLM models for robustness.

Medium-term: expand to international firms beyond the US, integrate analyst reports as a complementary signal source, and build a real-time dashboard.

Research extensions: explore connections to financial markets, test predictive power for employment and GDP, and compare to traditional survey-based measures.

We're open to suggestions and would welcome collaboration on any of these directions."

**Key points:**
- Three time horizons
- Opportunities for collaboration
- Open to feedback

**Timing:** 32:30-33:30

---

## SLIDE 25: Conclusion (1 minute)
**Script:**
"Let me wrap up with four key takeaways.

First, LLMs can extract structured investment signals from earnings calls at scale. This methodology works and is replicable.

Second, our hesitation index demonstrates genuine six-quarter predictive power with correlation of .77. That's strong for macro forecasting.

Third, the methodology is scalable to 200,000-plus transcripts with proper validation.

Fourth, this represents a novel real-time economic indicator with forward-looking properties that complements traditional statistical releases.

I'll stop there and open it up for questions. Thank you."

**Timing:** 33:30-34:30

---

## Q&A PREPARATION (Expanded)

**Q: Can you explain again how the LLM understands negation? That example was helpful.**
A: Sure. Traditional keyword search just looks for words. If the text says "We will NOT expand," keyword search sees "expand" and returns a match—a false positive. But an LLM has learned from millions of examples that "NOT expand" means the opposite of "expand." It understands syntactic structure and context. It's like how humans read—we don't just look for keywords, we understand the meaning of sentences. The LLM does the same thing, which is why it's so much more accurate for this task.

**Q: How do you know the LLM is coding things correctly? How do you validate?**
A: Great question. We use several validation approaches. First, we manually reviewed a sample of several hundred transcripts alongside the LLM outputs to check accuracy—the agreement rate was over 90%. Second, the aggregate time series make sense—they spike during periods of known uncertainty like COVID. Third, the predictive correlations are strong and economically interpretable. Fourth, we're testing across multiple LLM models to ensure robustness. But you're right that this is an area requiring ongoing vigilance.

**Q: What about firms that don't hold earnings calls?**
A: That's a legitimate coverage limitation. Smaller firms and private firms don't hold public earnings calls. However, the firms in our dataset represent roughly 60-70% of aggregate NFRI investment—these are the large, publicly-traded companies that do the bulk of capital investment in the economy. For smaller firms, we might be able to extend this methodology to other text sources like analyst sector reports or even private company filings, though those are harder to access systematically.

**Q: Why is structures so hard to predict?**
A: Structures investment—things like factories, office buildings, warehouses—is notoriously volatile and lumpy. A single large project can swing the numbers significantly. Also, structures often have very long planning and execution horizons—years, not quarters—so the timing between sentiment and realization is less predictable. Additionally, structures are more sensitive to interest rates and real estate market conditions, which can change quickly. So a correlation of .316, while modest, is actually respectable for structures forecasting.

**Q: Could this replace traditional BEA data?**
A: No, and that's not the goal. BEA data is the definitive measure of investment—it's comprehensive, methodologically rigorous, and essential. What our indicator provides is a complementary real-time signal. BEA data comes with a lag and is subject to revisions. Our measure is available continuously as earnings calls happen and is forward-looking. Think of it as an early warning system or nowcasting tool that complements, not replaces, official statistics.

**Q: What's the computational cost?**
A: For the initial historical processing of 200,000 transcripts, it took approximately [X days] on our GPU infrastructure. The marginal cost per transcript is roughly [X cents] depending on the model. Going forward, we only need to process new transcripts—maybe 2,000-3,000 per quarter—which is very manageable both computationally and cost-wise. The infrastructure requirements are modest by modern standards.

**Q: How sensitive are results to prompt design?**
A: Very sensitive, which is why we invested heavily in prompt engineering. Small changes in wording can affect output quality. However, once you have a good prompt, results are quite stable. We tested several variations and found reasonable consistency. The key is being very specific about what you're asking for and providing clear definitions. Vague prompts give noisy results. We borrowed heavily from Clayton et al.'s methodology, which went through extensive iteration.

**Q: Could other researchers replicate this?**
A: Yes, absolutely. The methodology is transparent—we're documenting everything in our research note. FactSet data is commercially available. Open-source LLMs are freely available. The main requirements are: access to the transcript data, compute infrastructure for LLM inference, and careful prompt engineering. The technical barrier is much lower than it used to be. We're happy to share our prompts and code to facilitate replication.

**Q: What about international expansion?**
A: That's a priority. The challenge is data access—FactSet coverage is weaker for non-US firms, and many countries don't have the same earnings call culture. But for major markets like Europe, UK, Japan, and Canada, there's sufficient transcript availability. We'd need to adapt the prompts slightly for different corporate cultures and terminology, but the core methodology transfers directly. Chinese firms are particularly interesting given the size of that economy, though language barriers add complexity.

---

## TIMING CHECKPOINTS (Expanded)
- Slides 1-5: 6:30 elapsed
- Slides 6-11: 14:30 elapsed
- Slides 12-16: 22:30 elapsed
- Slides 17-21: 29:30 elapsed
- Slides 22-25: 34:30 total

## DELIVERY TIPS
1. **For non-technical audience**: Use analogies ("survey questionnaire," "like a very smart search")
2. **Use examples liberally**: The momentum drop example, the negation example—these make concepts concrete
3. **Check for understanding**: Pause after Slide 5 (LLMs), Slide 11 (JSON to data), and Slide 17 (formula) to ask "Does this make sense so far?"
4. **Visual pointing**: Point to specific elements on slides, especially the tables and formulas
5. **Vary pace**: Slow down for technical concepts (PCA), speed up for familiar material (earnings calls)
6. **Invite questions**: "Feel free to stop me if anything is unclear"
7. **If running long**: Can compress Slides 13-16 by spending 30 seconds each instead of 90 seconds
8. **Energy management**: This is longer than typical—take a brief pause before Slide 12 to take a sip of water

## BACKUP SLIDES (Suggested)
Consider having these ready but not in the main deck:
- Detailed SQL query from FactSet
- Full prompt text (not simplified)
- Additional validation plots
- Comparison with ISM or other survey data
- Sector-level breakdowns
- Robustness across different LLM models
